<?php

return array(
    'code' => 'BSD',
    'sign' => '$',
    'sign_position' => 0,
    'sign_delim' => '',
    'title' => 'Bahamian dollar',
    'name' => array(
        array('dollar', 'dollars'),
        'B$',
    ),
    'frac_name' => array(
        array('cent', 'cents'),
    )
);