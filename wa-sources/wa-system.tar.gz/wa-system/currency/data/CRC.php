<?php

return array(
    'code' => 'CRC',
    'sign' => '₡',
    'sign_position' => 0,
    'sign_delim' => '',
    'title' => 'Costa Rican colon',
    'name' => array(
        array('colon', 'colones'),
    ),
    'frac_name' => array(
        array('centimo', 'centimos'),
    )
);