<?php

return array(
    'code' => 'HNL',
    'sign' => 'L',
    'sign_position' => 0,
    'sign_delim' => '',
    'title' => 'Honduran lempira',
    'name' => array(
        array('lempira', 'lempiras'),
    ),
    'frac_name' => array(
        array('centavo', 'centavos'),
    )
);