<?php

return array(
    'code' => 'HUF',
    'sign' => 'Ft',
    'sign_position' => null,
    'sign_delim' => null,
    'title' => 'Hungarian forint',
    'name' => array(
        array('forint', 'forints'),
    ),
    'frac_name' => array(
        //filler is no longer used
    )
);