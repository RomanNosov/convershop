<?php

return array(
    'code' => 'NOK',
    'sign' => 'kr',
    'sign_position' => null,
    'sign_delim' => null,
    'title' => 'Norwegian krone',
    'name' => array(
        array('krone', 'kroner'),
    ),
    'frac_name' => array(
		'ore',
    )
);