<?php 
$message = 'Can not connect to MySQL server.';
include('error.php');