<?php 

return array(
    'name' => 'Webasyst',
    'prefix' => 'webasyst',
    'analytics' => true,
    'version' => '1.3.3',
    'critical'=>'1.3.3',
    'vendor' => 'webasyst',
);
